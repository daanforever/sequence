<?PHP
include 'mathpublisher.php';

include("mathpublisher.php") ;

mathfilter("<m>f(x)=sqrt{x}</m>");


?>
